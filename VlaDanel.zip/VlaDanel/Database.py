import sqlite3

db = sqlite3.connect('Index')

rs = db.cursor()

#rs.execute('''create table Feedback(name varchar(50), phone varchar(10), email varchar(100), place varchar(150), msg varchar(500))''')
#db.commit()

rs.execute('''insert into Feedback values('Mary', '+4512546', 'gmail.com', 'atlanta', 'smthg')''')
db.commit()

rs.execute('select * from Feedback')
for i in rs:
    print(i)