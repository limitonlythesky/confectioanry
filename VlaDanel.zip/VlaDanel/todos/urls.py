from django.contrib import admin
from django.urls import path
from . import views
urlpatterns = [
    path('', views.Index, name='Index.html'),
    path('feedback_done/', views.feedback_done, name='feedback_done')
]
