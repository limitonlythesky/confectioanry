from django.shortcuts import render
from django.http import HttpResponse
import sqlite3
# Create your views here.

def Index(request):
    return render(request, "todos/index.html")

def feedback_done(request):
    db = sqlite3.connect('Index')

    rs = db.cursor()

    #rs.execute('''create table Feedback(name varchar(50), phone varchar(10), email varchar(100), place varchar(150), msg varchar(500))''')
    #db.commit()

    rs.execute('''insert into Feedback values('Mary', '+4512546', 'gmail.com', 'atlanta', 'smthg')''')
    db.commit()

    data = []

    rs.execute('select * from Feedback')
    for i in rs:
        data.append(i)
        print(i)
    return render(request, 'todos/feedback_done.html', {'data' : data})
